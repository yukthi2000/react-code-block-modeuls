import { withTheme } from 'styled-components';
import Snippet from './components/Snippet';

export default withTheme(Snippet);
