import { withTheme } from 'styled-components';
import CodeBlock from './components/CodeBlock';

export default withTheme(CodeBlock);
