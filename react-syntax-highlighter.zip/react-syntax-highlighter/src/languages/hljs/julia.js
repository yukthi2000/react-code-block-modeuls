import julia from "highlight.js/lib/languages/julia";
export default julia;
