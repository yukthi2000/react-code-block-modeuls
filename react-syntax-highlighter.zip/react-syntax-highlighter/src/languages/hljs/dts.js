import dts from "highlight.js/lib/languages/dts";
export default dts;
