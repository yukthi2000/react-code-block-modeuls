import subunit from "highlight.js/lib/languages/subunit";
export default subunit;
