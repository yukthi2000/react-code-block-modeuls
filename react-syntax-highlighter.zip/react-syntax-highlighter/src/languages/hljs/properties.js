import properties from "highlight.js/lib/languages/properties";
export default properties;
