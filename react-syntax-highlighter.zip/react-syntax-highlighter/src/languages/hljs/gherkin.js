import gherkin from "highlight.js/lib/languages/gherkin";
export default gherkin;
