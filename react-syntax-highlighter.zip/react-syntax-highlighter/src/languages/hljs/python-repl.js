import pythonRepl from "highlight.js/lib/languages/python-repl";
export default pythonRepl;
