import n1ql from "highlight.js/lib/languages/n1ql";
export default n1ql;
