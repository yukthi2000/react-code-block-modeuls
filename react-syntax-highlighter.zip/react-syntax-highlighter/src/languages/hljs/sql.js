import sql from "highlight.js/lib/languages/sql";
export default sql;
