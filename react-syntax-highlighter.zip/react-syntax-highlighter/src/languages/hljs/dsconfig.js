import dsconfig from "highlight.js/lib/languages/dsconfig";
export default dsconfig;
