import monkey from "highlight.js/lib/languages/monkey";
export default monkey;
