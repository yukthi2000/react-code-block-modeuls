import django from "highlight.js/lib/languages/django";
export default django;
