import nim from "highlight.js/lib/languages/nim";
export default nim;
