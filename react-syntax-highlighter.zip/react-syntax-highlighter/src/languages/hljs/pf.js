import pf from "highlight.js/lib/languages/pf";
export default pf;
