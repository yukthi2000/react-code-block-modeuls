import go from "highlight.js/lib/languages/go";
export default go;
