import fix from "highlight.js/lib/languages/fix";
export default fix;
