import thrift from "highlight.js/lib/languages/thrift";
export default thrift;
