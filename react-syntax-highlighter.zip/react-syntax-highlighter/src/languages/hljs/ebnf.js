import ebnf from "highlight.js/lib/languages/ebnf";
export default ebnf;
