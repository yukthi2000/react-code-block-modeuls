import java from "highlight.js/lib/languages/java";
export default java;
