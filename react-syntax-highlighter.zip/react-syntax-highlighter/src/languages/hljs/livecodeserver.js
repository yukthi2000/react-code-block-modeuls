import livecodeserver from "highlight.js/lib/languages/livecodeserver";
export default livecodeserver;
