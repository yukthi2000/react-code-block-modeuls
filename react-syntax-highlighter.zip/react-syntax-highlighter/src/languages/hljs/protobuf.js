import protobuf from "highlight.js/lib/languages/protobuf";
export default protobuf;
