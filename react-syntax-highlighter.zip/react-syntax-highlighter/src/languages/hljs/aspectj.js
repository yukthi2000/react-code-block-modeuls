import aspectj from "highlight.js/lib/languages/aspectj";
export default aspectj;
