import bnf from "highlight.js/lib/languages/bnf";
export default bnf;
