import javascript from "highlight.js/lib/languages/javascript";
export default javascript;
