import ocaml from "highlight.js/lib/languages/ocaml";
export default ocaml;
