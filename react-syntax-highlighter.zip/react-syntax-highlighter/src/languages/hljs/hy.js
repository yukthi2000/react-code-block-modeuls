import hy from "highlight.js/lib/languages/hy";
export default hy;
