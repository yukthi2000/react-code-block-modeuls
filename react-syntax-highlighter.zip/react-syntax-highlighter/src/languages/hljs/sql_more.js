import sqlMore from "highlight.js/lib/languages/sql_more";
export default sqlMore;
