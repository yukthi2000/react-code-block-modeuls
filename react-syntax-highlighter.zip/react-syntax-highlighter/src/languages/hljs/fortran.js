import fortran from "highlight.js/lib/languages/fortran";
export default fortran;
