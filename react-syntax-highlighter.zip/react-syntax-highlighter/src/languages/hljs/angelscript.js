import angelscript from "highlight.js/lib/languages/angelscript";
export default angelscript;
