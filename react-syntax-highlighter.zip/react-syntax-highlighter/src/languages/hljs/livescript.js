import livescript from "highlight.js/lib/languages/livescript";
export default livescript;
