import powershell from "highlight.js/lib/languages/powershell";
export default powershell;
