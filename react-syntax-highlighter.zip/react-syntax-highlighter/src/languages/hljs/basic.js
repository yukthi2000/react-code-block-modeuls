import basic from "highlight.js/lib/languages/basic";
export default basic;
