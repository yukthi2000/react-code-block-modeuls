import pgsql from "highlight.js/lib/languages/pgsql";
export default pgsql;
