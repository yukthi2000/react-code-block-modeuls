import hsp from "highlight.js/lib/languages/hsp";
export default hsp;
