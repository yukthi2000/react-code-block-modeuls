import prolog from "highlight.js/lib/languages/prolog";
export default prolog;
