import shell from "highlight.js/lib/languages/shell";
export default shell;
