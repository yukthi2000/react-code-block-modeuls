import http from "highlight.js/lib/languages/http";
export default http;
