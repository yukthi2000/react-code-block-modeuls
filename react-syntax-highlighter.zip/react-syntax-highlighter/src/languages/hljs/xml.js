import xml from "highlight.js/lib/languages/xml";
export default xml;
