import scilab from "highlight.js/lib/languages/scilab";
export default scilab;
