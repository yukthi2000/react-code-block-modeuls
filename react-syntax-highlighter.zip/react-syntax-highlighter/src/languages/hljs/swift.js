import swift from "highlight.js/lib/languages/swift";
export default swift;
