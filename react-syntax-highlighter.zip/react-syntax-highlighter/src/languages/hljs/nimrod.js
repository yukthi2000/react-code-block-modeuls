import nimrod from "highlight.js/lib/languages/nimrod";
export default nimrod;
