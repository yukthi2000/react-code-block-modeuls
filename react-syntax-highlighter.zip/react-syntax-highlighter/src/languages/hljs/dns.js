import dns from "highlight.js/lib/languages/dns";
export default dns;
