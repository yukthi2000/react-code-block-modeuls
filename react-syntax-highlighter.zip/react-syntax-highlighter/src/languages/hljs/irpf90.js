import irpf90 from "highlight.js/lib/languages/irpf90";
export default irpf90;
