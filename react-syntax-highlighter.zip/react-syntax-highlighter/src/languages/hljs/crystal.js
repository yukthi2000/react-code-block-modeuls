import crystal from "highlight.js/lib/languages/crystal";
export default crystal;
