import objectivec from "highlight.js/lib/languages/objectivec";
export default objectivec;
