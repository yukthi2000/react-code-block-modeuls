import zephir from "highlight.js/lib/languages/zephir";
export default zephir;
