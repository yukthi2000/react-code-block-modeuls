import matlab from "highlight.js/lib/languages/matlab";
export default matlab;
