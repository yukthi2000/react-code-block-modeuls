import scheme from "highlight.js/lib/languages/scheme";
export default scheme;
