import nix from "highlight.js/lib/languages/nix";
export default nix;
