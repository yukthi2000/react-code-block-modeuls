import cpp from "highlight.js/lib/languages/cpp";
export default cpp;
