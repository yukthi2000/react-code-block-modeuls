import oneC from "highlight.js/lib/languages/1c";
export default oneC;
