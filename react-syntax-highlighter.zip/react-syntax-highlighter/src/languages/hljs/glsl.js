import glsl from "highlight.js/lib/languages/glsl";
export default glsl;
