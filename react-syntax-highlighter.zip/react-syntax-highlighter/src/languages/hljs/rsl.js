import rsl from "highlight.js/lib/languages/rsl";
export default rsl;
