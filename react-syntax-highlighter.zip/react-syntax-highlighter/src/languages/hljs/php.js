import php from "highlight.js/lib/languages/php";
export default php;
