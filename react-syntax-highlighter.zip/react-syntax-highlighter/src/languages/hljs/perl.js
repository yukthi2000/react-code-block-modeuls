import perl from "highlight.js/lib/languages/perl";
export default perl;
