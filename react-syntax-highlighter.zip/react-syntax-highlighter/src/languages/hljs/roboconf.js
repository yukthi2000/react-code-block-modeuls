import roboconf from "highlight.js/lib/languages/roboconf";
export default roboconf;
