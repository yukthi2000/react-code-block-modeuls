import flix from "highlight.js/lib/languages/flix";
export default flix;
