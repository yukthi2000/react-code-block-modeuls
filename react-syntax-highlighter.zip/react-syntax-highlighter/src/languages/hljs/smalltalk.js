import smalltalk from "highlight.js/lib/languages/smalltalk";
export default smalltalk;
