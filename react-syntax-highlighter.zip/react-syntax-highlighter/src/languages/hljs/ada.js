import ada from "highlight.js/lib/languages/ada";
export default ada;
