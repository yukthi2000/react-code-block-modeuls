import ruleslanguage from "highlight.js/lib/languages/ruleslanguage";
export default ruleslanguage;
