import gcode from "highlight.js/lib/languages/gcode";
export default gcode;
