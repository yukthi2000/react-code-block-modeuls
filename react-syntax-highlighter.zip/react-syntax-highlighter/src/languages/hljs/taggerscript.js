import taggerscript from "highlight.js/lib/languages/taggerscript";
export default taggerscript;
