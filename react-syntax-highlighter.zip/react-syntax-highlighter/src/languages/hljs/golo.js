import golo from "highlight.js/lib/languages/golo";
export default golo;
