import maxima from "highlight.js/lib/languages/maxima";
export default maxima;
