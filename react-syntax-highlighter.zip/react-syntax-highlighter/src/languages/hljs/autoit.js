import autoit from "highlight.js/lib/languages/autoit";
export default autoit;
