import tt2 from "refractor/lang/tt2.js";;
export default tt2;
