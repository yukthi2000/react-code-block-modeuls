import n1ql from "refractor/lang/n1ql.js";;
export default n1ql;
