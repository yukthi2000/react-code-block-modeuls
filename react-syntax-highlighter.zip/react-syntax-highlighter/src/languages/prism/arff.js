import arff from "refractor/lang/arff.js";;
export default arff;
