import pascaligo from "refractor/lang/pascaligo.js";;
export default pascaligo;
