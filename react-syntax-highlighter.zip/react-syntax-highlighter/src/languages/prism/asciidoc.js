import asciidoc from "refractor/lang/asciidoc.js";;
export default asciidoc;
