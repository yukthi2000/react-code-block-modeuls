import promql from "refractor/lang/promql.js";;
export default promql;
