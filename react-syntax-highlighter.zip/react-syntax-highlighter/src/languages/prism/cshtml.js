import cshtml from "refractor/lang/cshtml.js";;
export default cshtml;
