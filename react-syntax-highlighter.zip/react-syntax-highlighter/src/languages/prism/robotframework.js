import robotframework from "refractor/lang/robotframework.js";;
export default robotframework;
