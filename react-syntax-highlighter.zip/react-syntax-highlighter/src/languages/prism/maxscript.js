import maxscript from "refractor/lang/maxscript.js";;
export default maxscript;
