import al from "refractor/lang/al.js";;
export default al;
