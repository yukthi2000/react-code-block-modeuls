import jolie from "refractor/lang/jolie.js";;
export default jolie;
