import json from "refractor/lang/json.js";;
export default json;
