import firestoreSecurityRules from "refractor/lang/firestore-security-rules.js";;
export default firestoreSecurityRules;
