import antlr4 from "refractor/lang/antlr4.js";;
export default antlr4;
