import qsharp from "refractor/lang/qsharp.js";;
export default qsharp;
