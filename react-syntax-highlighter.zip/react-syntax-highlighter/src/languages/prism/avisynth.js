import avisynth from "refractor/lang/avisynth.js";;
export default avisynth;
