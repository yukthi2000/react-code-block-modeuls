import solidity from "refractor/lang/solidity.js";;
export default solidity;
