import gdscript from "refractor/lang/gdscript.js";;
export default gdscript;
