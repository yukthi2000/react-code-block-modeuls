import parigp from "refractor/lang/parigp.js";;
export default parigp;
