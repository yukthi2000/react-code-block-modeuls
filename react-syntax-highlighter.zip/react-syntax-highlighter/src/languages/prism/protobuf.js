import protobuf from "refractor/lang/protobuf.js";;
export default protobuf;
