import gml from "refractor/lang/gml.js";;
export default gml;
