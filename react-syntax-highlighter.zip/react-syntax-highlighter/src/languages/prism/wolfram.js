import wolfram from "refractor/lang/wolfram.js";;
export default wolfram;
