import rip from "refractor/lang/rip.js";;
export default rip;
