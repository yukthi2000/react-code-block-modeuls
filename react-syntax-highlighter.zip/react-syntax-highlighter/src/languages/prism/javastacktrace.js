import javastacktrace from "refractor/lang/javastacktrace.js";;
export default javastacktrace;
