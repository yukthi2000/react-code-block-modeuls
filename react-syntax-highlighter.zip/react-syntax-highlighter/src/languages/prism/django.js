import django from "refractor/lang/django.js";;
export default django;
