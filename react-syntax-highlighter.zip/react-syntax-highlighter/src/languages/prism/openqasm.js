import openqasm from "refractor/lang/openqasm.js";;
export default openqasm;
