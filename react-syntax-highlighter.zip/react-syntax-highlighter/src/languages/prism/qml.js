import qml from "refractor/lang/qml.js";;
export default qml;
