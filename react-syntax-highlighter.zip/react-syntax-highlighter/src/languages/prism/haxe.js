import haxe from "refractor/lang/haxe.js";;
export default haxe;
