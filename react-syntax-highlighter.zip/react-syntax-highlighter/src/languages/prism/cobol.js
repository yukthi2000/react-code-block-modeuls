import cobol from "refractor/lang/cobol.js";;
export default cobol;
