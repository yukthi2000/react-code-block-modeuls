import haml from "refractor/lang/haml.js";;
export default haml;
