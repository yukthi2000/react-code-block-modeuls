import gn from "refractor/lang/gn.js";;
export default gn;
