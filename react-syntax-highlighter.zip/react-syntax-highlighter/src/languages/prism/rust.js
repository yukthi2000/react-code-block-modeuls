import rust from "refractor/lang/rust.js";;
export default rust;
