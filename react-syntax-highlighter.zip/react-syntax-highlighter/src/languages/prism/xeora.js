import xeora from "refractor/lang/xeora.js";;
export default xeora;
