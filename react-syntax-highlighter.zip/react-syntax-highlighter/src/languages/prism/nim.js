import nim from "refractor/lang/nim.js";;
export default nim;
