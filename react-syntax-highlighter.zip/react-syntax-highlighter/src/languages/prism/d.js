import d from "refractor/lang/d.js";;
export default d;
