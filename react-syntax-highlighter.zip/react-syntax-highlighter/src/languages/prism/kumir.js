import kumir from "refractor/lang/kumir.js";;
export default kumir;
