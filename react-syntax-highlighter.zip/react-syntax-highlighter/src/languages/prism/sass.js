import sass from "refractor/lang/sass.js";;
export default sass;
