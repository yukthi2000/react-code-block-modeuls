import dart from "refractor/lang/dart.js";;
export default dart;
