import haskell from "refractor/lang/haskell.js";;
export default haskell;
