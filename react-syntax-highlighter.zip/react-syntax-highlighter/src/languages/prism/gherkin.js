import gherkin from "refractor/lang/gherkin.js";;
export default gherkin;
