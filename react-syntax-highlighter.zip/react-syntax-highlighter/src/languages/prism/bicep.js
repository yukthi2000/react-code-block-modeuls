import bicep from "refractor/lang/bicep.js";;
export default bicep;
