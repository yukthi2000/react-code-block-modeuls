import apacheconf from "refractor/lang/apacheconf.js";;
export default apacheconf;
