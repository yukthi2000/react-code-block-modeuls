import prolog from "refractor/lang/prolog.js";;
export default prolog;
