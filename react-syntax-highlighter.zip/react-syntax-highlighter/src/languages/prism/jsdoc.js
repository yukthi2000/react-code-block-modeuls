import jsdoc from "refractor/lang/jsdoc.js";;
export default jsdoc;
