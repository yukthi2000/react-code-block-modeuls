import purebasic from "refractor/lang/purebasic.js";;
export default purebasic;
