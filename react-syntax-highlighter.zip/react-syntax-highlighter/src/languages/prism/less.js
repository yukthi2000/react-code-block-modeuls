import less from "refractor/lang/less.js";;
export default less;
