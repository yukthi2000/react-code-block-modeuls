import dax from "refractor/lang/dax.js";;
export default dax;
