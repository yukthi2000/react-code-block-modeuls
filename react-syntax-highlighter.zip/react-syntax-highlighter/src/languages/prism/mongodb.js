import mongodb from "refractor/lang/mongodb.js";;
export default mongodb;
