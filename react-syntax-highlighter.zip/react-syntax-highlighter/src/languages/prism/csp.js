import csp from "refractor/lang/csp.js";;
export default csp;
