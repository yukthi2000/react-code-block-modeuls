import go from "refractor/lang/go.js";;
export default go;
