import kusto from "refractor/lang/kusto.js";;
export default kusto;
