import clojure from "refractor/lang/clojure.js";;
export default clojure;
