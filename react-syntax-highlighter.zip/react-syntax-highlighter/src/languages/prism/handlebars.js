import handlebars from "refractor/lang/handlebars.js";;
export default handlebars;
