import log from "refractor/lang/log.js";;
export default log;
