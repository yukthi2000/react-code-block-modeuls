import mermaid from "refractor/lang/mermaid.js";;
export default mermaid;
