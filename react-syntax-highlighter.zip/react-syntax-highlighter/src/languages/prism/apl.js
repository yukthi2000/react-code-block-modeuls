import apl from "refractor/lang/apl.js";;
export default apl;
