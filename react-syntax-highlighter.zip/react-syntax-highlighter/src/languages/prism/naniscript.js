import naniscript from "refractor/lang/naniscript.js";;
export default naniscript;
