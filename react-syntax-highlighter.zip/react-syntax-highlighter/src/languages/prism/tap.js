import tap from "refractor/lang/tap.js";;
export default tap;
