import splunkSpl from "refractor/lang/splunk-spl.js";;
export default splunkSpl;
