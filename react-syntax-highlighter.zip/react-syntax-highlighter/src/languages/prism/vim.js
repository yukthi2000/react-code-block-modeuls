import vim from "refractor/lang/vim.js";;
export default vim;
