import systemd from "refractor/lang/systemd.js";;
export default systemd;
