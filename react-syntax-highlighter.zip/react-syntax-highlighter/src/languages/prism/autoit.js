import autoit from "refractor/lang/autoit.js";;
export default autoit;
