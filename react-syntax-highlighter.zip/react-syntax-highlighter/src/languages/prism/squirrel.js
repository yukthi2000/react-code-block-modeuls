import squirrel from "refractor/lang/squirrel.js";;
export default squirrel;
