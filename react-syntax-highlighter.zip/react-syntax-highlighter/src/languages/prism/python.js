import python from "refractor/lang/python.js";;
export default python;
