import psl from "refractor/lang/psl.js";;
export default psl;
