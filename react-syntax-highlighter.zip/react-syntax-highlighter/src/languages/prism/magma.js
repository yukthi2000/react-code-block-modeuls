import magma from "refractor/lang/magma.js";;
export default magma;
