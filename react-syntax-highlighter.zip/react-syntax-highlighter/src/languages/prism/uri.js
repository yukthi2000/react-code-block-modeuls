import uri from "refractor/lang/uri.js";;
export default uri;
