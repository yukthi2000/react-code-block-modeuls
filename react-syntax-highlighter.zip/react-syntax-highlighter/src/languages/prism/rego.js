import rego from "refractor/lang/rego.js";;
export default rego;
