import stan from "refractor/lang/stan.js";;
export default stan;
