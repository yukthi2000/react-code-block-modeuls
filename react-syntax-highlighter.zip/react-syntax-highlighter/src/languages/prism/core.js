import Prism from 'prismjs';
export default Prism.languages.core;
